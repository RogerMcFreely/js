// Code goes here
var animal = "cat";

switch (animal) {
  case "cat":
    alert("meow");
    break;
  case "dog":
    alert("woof");
    break;
  case "horse":
    alert("neigh");
    break;
  default:
    alert("Unknow animal!");
    break;
}